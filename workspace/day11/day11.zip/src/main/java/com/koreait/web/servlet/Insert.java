package com.koreait.web.servlet;


public class Insert {

}
